#utils.py

global contactList
contactList = {}

    
global databaseSet
databaseSet = {}